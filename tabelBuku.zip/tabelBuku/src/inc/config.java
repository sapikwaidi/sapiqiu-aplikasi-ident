/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inc;
//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author sapik
 */
public class config {
    public static Connection conn;
    
    public static Connection Conn(){
  
        try {
            String className = "com.mysql.jdbc.Driver";
            Class.forName(className);
            System.out.println("load driver jdbc succses");
        } catch (Exception e) {
            System.out.println("load driver jdbc field"+e.getMessage());
        }
        try {
            String url = "jdbc:mysql://localhost/toko_buku";
            String username = "root";
            String password = "";
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("conection dataBase succses");
        } catch (Exception e) {
            System.out.println("conction dataBase field"+e.getMessage());
        }
        return conn;
    }
    
//    test conection
    public static void main(String[] args) {
        System.out.println(Conn()); //because static maka class ga usah di cantumkan
        System.out.println(config.Conn());//ini tidak efisien
    }
}
